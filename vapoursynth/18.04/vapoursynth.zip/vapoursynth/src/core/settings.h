#ifndef SETTINGS_H
#define SETTINGS_H

VSMap *readSettings(const std::string &path);

#endif
