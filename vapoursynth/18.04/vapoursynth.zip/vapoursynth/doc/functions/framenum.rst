FrameNum (Text)
===============

.. function:: FrameNum(clip clip[, int alignment=7, int scale=1])
   :module: text

   Prints the current frame number.

   This is a convenience function for *Text*.
