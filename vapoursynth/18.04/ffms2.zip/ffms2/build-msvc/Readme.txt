BUILD INSTRUCTIONS

The included projects require Visual Studio 2017.

Libraries needed: recent FFmpeg, zlib, Avisynth+ (MT branch) headers.

All include and library paths are set to be relative to the ffms2 directory by default.